import { useState } from 'react';
import MuseumIntroPage from './components/MuseumIntroPage';
import CulturalHeritagePage from './components/CulturalHeritagePage';
import WorkReportPage from './components/WorkReportPage';
import AdminPage from './components/AdminPage';
import Navigation from './components/Navigation';

function App() {
  const [activeIndex, setActiveIndex] = useState(0);

  const pages = [
    <MuseumIntroPage />,
    <CulturalHeritagePage />,
    <WorkReportPage />,
    <AdminPage />
  ];

  return (
    <div className="min-h-screen pb-24">
      {pages[activeIndex]}
      <Navigation activeIndex={activeIndex} onNavigate={setActiveIndex} />
    </div>
  );
}

export default App;