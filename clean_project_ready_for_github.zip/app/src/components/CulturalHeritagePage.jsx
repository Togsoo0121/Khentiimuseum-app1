const CulturalHeritagePage = () => {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Соёлын өв</h1>
      <p>Энд сурдчилсан соёлын өвийн талаарх мэдээлэл орно.</p>
    </div>
  );
};

export default CulturalHeritagePage;