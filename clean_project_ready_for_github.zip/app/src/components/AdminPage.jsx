const AdminPage = () => {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Удирдлагын хэсэг</h1>
      <p>Энэ хэсгээр дамжуулж текст, зураг, бичлэг нэмэх боломжтой.</p>
    </div>
  );
};

export default AdminPage;