const WorkReportPage = () => {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Хийсэн ажлууд</h1>
      <p>Сүүлийн үед хийгдсэн ажлуудын тайланг энд харуулна.</p>
    </div>
  );
};

export default WorkReportPage;